import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Search,
  FolderPlus,
  Layers,
  ArrowRight,
  ShieldCheck,
  Hash,
  UserCheck,
  Briefcase,
  PlayCircle,
  RotateCcw,
  LogOut,
  X,
  FileText,
  Clock,
  Sparkles,
  ChevronRight,
  Trash2,
  ExternalLink,
  Plus,
  CheckCircle2,
  Inbox,
  Lock,
  Unlock,
  User,
} from 'lucide-react';
import { ProjectEntity, AuthUser, UserRole } from '../types';
import { CreateProjectOrWaterfallModal } from './CreateProjectOrWaterfallModal';

interface ProjectPortfolioLandingProps {
  currentUser: AuthUser | null;
  projects: ProjectEntity[];
  onOpenProject: (projectId: string, waterfallId?: string) => void;
  onCreateProject: (details: any) => void;
  onAddWaterfallToProject: (projectId: string, waterfallName: string) => void;
  onDeleteProject: (projectId: string) => void;
  onResetToCleanSlate: () => void;
  onLogout: () => void;
}

export const ProjectPortfolioLanding: React.FC<ProjectPortfolioLandingProps> = ({
  currentUser,
  projects,
  onOpenProject,
  onCreateProject,
  onAddWaterfallToProject,
  onDeleteProject,
  onResetToCleanSlate,
  onLogout,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedWaterfallByProject, setSelectedWaterfallByProject] = useState<Record<string, string>>({});
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Close search suggestions on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter projects by Issue#, Title, Assignee, or leads
  const filteredProjects = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return projects;

    return projects.filter((proj) => {
      const issueNum = (proj.projectDetails.issueNumber || '').toLowerCase();
      const title = proj.projectDetails.issueTitle.toLowerCase();
      const desc = (proj.projectDetails.issueDescription || '').toLowerCase();
      const frc = proj.projectDetails.frcName.toLowerCase();
      const analyst = proj.projectDetails.analystName.toLowerCase();
      const assigneeName = (proj.projectDetails.assignedToName || '').toLowerCase();
      const assigneeEmail = (proj.projectDetails.assignedToEmail || '').toLowerCase();
      const waterfalls = proj.waterfalls.map((w) => w.name.toLowerCase()).join(' ');

      return (
        issueNum.includes(q) ||
        title.includes(q) ||
        desc.includes(q) ||
        frc.includes(q) ||
        analyst.includes(q) ||
        assigneeName.includes(q) ||
        assigneeEmail.includes(q) ||
        waterfalls.includes(q)
      );
    });
  }, [projects, searchQuery]);

  // Aggregate portfolio metrics
  const totalWaterfalls = useMemo(
    () => projects.reduce((acc, p) => acc + (p.waterfalls?.length || 0), 0),
    [projects]
  );
  const totalSteps = useMemo(
    () =>
      projects.reduce(
        (acc, p) =>
          acc +
          p.waterfalls.reduce((wAcc, w) => wAcc + (w.rows?.length || 0), 0),
        0
      ),
    [projects]
  );

  // Prompt suggestions with valid project Issue Numbers
  const validProjectSuggestions = useMemo(() => {
    return projects.map((p) => {
      const issueNum = p.projectDetails.issueNumber || 'ISS-001';
      return {
        id: p.id,
        issueNumber: issueNum,
        title: p.projectDetails.issueTitle,
        assignedToName: p.projectDetails.assignedToName || p.projectDetails.frcName,
        waterfallsCount: p.waterfalls.length,
        activeWaterfallId: p.activeWaterfallId || p.waterfalls[0]?.id,
      };
    });
  }, [projects]);

  const handleSelectSuggestion = (projId: string, waterfallId?: string) => {
    setIsSearchFocused(false);
    onOpenProject(projId, waterfallId);
  };

  const handleApplyFilterChip = (filterText: string) => {
    setSearchQuery(filterText);
    setIsSearchFocused(false);
  };

  // Check if current user has edit permission for a project
  const checkUserCanEdit = (project: ProjectEntity) => {
    if (!currentUser) return false;
    const userEmail = currentUser.email.toLowerCase();
    const userName = currentUser.name.toLowerCase();

    const assignedEmail = (project.projectDetails.assignedToEmail || '').toLowerCase();
    const assignedName = (project.projectDetails.assignedToName || '').toLowerCase();
    const frcName = (project.projectDetails.frcName || '').toLowerCase();
    const analystName = (project.projectDetails.analystName || '').toLowerCase();

    if (assignedEmail) {
      return assignedEmail === userEmail || assignedName === userName;
    }
    return frcName === userName || analystName === userName || frcName === userEmail || analystName === userEmail;
  };

  return (
    <div className="min-h-screen bg-stone-100 text-stone-900 flex flex-col font-sans antialiased">
      {/* Top Navigation Bar */}
      <header className="bg-white border-b border-stone-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-stone-900 text-emerald-400 font-black flex items-center justify-center text-xs tracking-wider shadow-sm">
              GOV
            </div>
            <div>
              <span className="text-sm font-bold text-stone-900 tracking-tight block">
                Requirements Waterfall Governance
              </span>
              <span className="text-[11px] text-stone-500 font-medium hidden sm:block">
                Project Portfolio &amp; Issue Tracking Portal
              </span>
            </div>
          </div>

          {/* Action CTAs & User Profile */}
          <div className="flex items-center gap-3">
            {/* Create Project Button */}
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-xl transition-all shadow-xs"
            >
              <FolderPlus className="w-4 h-4" />
              <span>Create Project</span>
            </button>

            {/* User Session Info */}
            {currentUser && (
              <div className="flex items-center gap-2 pl-3 border-l border-stone-200">
                <div className="flex items-center gap-2 text-xs">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs text-white shadow-2xs ${
                      currentUser.persona === 'frc' ? 'bg-emerald-600' : 'bg-blue-600'
                    }`}
                  >
                    {currentUser.name.charAt(0)}
                  </div>
                  <div className="hidden sm:block text-left leading-tight">
                    <span className="block font-bold text-stone-900 text-xs truncate max-w-[130px]">
                      {currentUser.name}
                    </span>
                    <span className="text-[10px] text-stone-500 font-medium truncate max-w-[130px] block">
                      {currentUser.email}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onLogout}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-lg transition-colors text-xs font-medium"
                  title="Sign out of Governance Portal"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden md:inline text-[11px]">Sign Out</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Portfolio Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Welcome & Overview Banner */}
        <div className="bg-white rounded-3xl border border-stone-200/90 p-6 sm:p-8 shadow-sm flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200/70">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Project Portfolio Hub · Governance &amp; Regulatory Scoping</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-stone-900 tracking-tight">
              {currentUser ? `Welcome, ${currentUser.name}` : 'Project Governance Portfolio'}
            </h1>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              Find an existing project by Issue Number to access requirement waterfall workflows,
              audit logs, quantitative data counts, and downstream Excel deliverable exports.
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
            <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 text-center min-w-[110px]">
              <span className="text-2xl font-black text-stone-900 block font-mono">
                {projects.length}
              </span>
              <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
                {projects.length === 1 ? 'Project' : 'Projects'}
              </span>
            </div>
            <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 text-center min-w-[110px]">
              <span className="text-2xl font-black text-purple-700 block font-mono">
                {totalWaterfalls}
              </span>
              <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
                Waterfalls
              </span>
            </div>
            <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 text-center min-w-[110px]">
              <span className="text-2xl font-black text-blue-700 block font-mono">
                {totalSteps}
              </span>
              <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
                Total Steps
              </span>
            </div>
          </div>
        </div>

        {/* SEARCH & PROMPT SUGGESTIONS SECTION */}
        <div className="space-y-4">
          <div className="relative" ref={searchContainerRef}>
            <div className="relative flex items-center">
              <Search className="w-5 h-5 text-stone-400 absolute left-4 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onFocus={() => setIsSearchFocused(true)}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Find an existing project by Issue Number (e.g. REQ-4421, ISS-2026-A1), title, or keyword..."
                className="w-full pl-12 pr-12 py-3.5 bg-white border border-stone-300 rounded-2xl text-xs sm:text-sm text-stone-900 placeholder-stone-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-sm transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-4 text-stone-400 hover:text-stone-700 p-1 rounded-md transition-colors"
                  title="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* TYPEAHEAD PROMPT SUGGESTIONS DROPDOWN (when focused or typing) */}
            {isSearchFocused && validProjectSuggestions.length > 0 && (
              <div className="absolute left-0 right-0 mt-2 bg-white rounded-2xl border border-stone-200 shadow-xl z-20 overflow-hidden animate-in fade-in duration-150">
                <div className="px-4 py-2.5 bg-stone-50 border-b border-stone-200 flex items-center justify-between text-xs text-stone-500">
                  <span className="font-semibold text-stone-700 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    Prompt Suggestions with Valid Issue #:
                  </span>
                  <span className="text-[11px]">Click to launch workspace</span>
                </div>
                <div className="max-h-64 overflow-y-auto divide-y divide-stone-100">
                  {validProjectSuggestions
                    .filter((p) => {
                      if (!searchQuery.trim()) return true;
                      const q = searchQuery.toLowerCase();
                      return (
                        p.issueNumber.toLowerCase().includes(q) ||
                        p.title.toLowerCase().includes(q) ||
                        p.assignedToName.toLowerCase().includes(q)
                      );
                    })
                    .slice(0, 5)
                    .map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleSelectSuggestion(item.id, item.activeWaterfallId)}
                        className="w-full px-4 py-3 text-left hover:bg-blue-50/60 transition-colors flex items-center justify-between gap-3 group"
                      >
                        <div className="space-y-0.5 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                              {item.issueNumber}
                            </span>
                            <span className="text-[11px] text-stone-500">
                              Assigned: {item.assignedToName}
                            </span>
                            <span className="text-[11px] text-stone-400">
                              ({item.waterfallsCount} {item.waterfallsCount === 1 ? 'waterfall' : 'waterfalls'})
                            </span>
                          </div>
                          <p className="text-xs font-semibold text-stone-900 truncate">
                            {item.title}
                          </p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-stone-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all shrink-0" />
                      </button>
                    ))}
                </div>
              </div>
            )}
          </div>

          {/* Quick Filter Prompt Chips */}
          {validProjectSuggestions.length > 0 && (
            <div className="flex flex-wrap items-center gap-1.5 text-xs">
              <span className="text-stone-500 font-medium flex items-center gap-1 mr-1">
                <Hash className="w-3.5 h-3.5 text-stone-400" />
                Quick Issue# suggestions:
              </span>
              {validProjectSuggestions.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => handleApplyFilterChip(p.issueNumber)}
                  className="px-2.5 py-1 rounded-lg bg-white border border-stone-200 text-stone-700 hover:bg-stone-50 hover:border-blue-300 font-mono text-[11px] font-semibold transition-colors shadow-2xs"
                  title={`Filter by Issue#: ${p.issueNumber}`}
                >
                  {p.issueNumber}
                </button>
              ))}
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="px-2 py-1 text-xs text-rose-600 hover:text-rose-800 font-semibold ml-2"
                >
                  Clear Filter
                </button>
              )}
            </div>
          )}
        </div>

        {/* RESULTS SECTION */}
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span className="font-semibold text-stone-700">
              Showing {filteredProjects.length} of {projects.length}{' '}
              {projects.length === 1 ? 'Project' : 'Projects'}
            </span>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onResetToCleanSlate}
                className="inline-flex items-center gap-1 text-[11px] text-stone-500 hover:text-stone-800 transition-colors"
                title="Reset portfolio to 0 projects for clean verification"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset to Blank Slate</span>
              </button>
            </div>
          </div>

          {/* 1. BLANK SEARCH RESULT (when query has no matches) */}
          {searchQuery && filteredProjects.length === 0 && (
            <div className="bg-white rounded-3xl border border-stone-200 p-8 sm:p-12 text-center space-y-4 animate-in fade-in duration-150">
              <div className="w-12 h-12 rounded-2xl bg-stone-100 text-stone-400 flex items-center justify-center mx-auto">
                <Search className="w-6 h-6" />
              </div>
              <div className="space-y-1.5 max-w-md mx-auto">
                <h3 className="text-base font-bold text-stone-900">
                  No projects found matching "{searchQuery}"
                </h3>
                <p className="text-xs text-stone-500 leading-relaxed">
                  We checked Issue numbers, titles, and assignee names. No matching records were
                  found. You can create a new project using this Issue Number or clear your search query.
                </p>
              </div>
              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-stone-100 text-stone-700 hover:bg-stone-200 transition-colors"
                >
                  Clear Search
                </button>
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(true)}
                  className="px-4 py-2 text-xs font-bold rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-colors shadow-xs flex items-center gap-1.5"
                >
                  <FolderPlus className="w-3.5 h-3.5" />
                  <span>Create Project with "{searchQuery}"</span>
                </button>
              </div>
            </div>
          )}

          {/* 2. COMPLETELY BLANK PORTFOLIO (0 projects in system) */}
          {!searchQuery && projects.length === 0 && (
            <div className="bg-white rounded-3xl border border-stone-200 p-8 sm:p-12 text-center space-y-4 animate-in fade-in duration-150">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                <Inbox className="w-6 h-6" />
              </div>
              <div className="space-y-1.5 max-w-md mx-auto">
                <h3 className="text-base font-bold text-stone-900">
                  Your Project Portfolio is Empty
                </h3>
                <p className="text-xs text-stone-500 leading-relaxed">
                  No projects are currently configured. Create a fresh project with an alphanumeric
                  Issue Number to start scoping your requirements waterfall.
                </p>
              </div>
              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(true)}
                  className="px-4 py-2 text-xs font-bold rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-colors shadow-xs flex items-center gap-1.5"
                >
                  <FolderPlus className="w-3.5 h-3.5" />
                  <span>Create First Project</span>
                </button>
              </div>
            </div>
          )}

          {/* 3. PROJECT CARDS GRID */}
          {filteredProjects.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProjects.map((project) => {
                const totalProjSteps = project.waterfalls.reduce(
                  (acc, w) => acc + (w.rows?.length || 0),
                  0
                );
                const currentSelectedWfId =
                  selectedWaterfallByProject[project.id] ||
                  project.activeWaterfallId ||
                  project.waterfalls[0]?.id;

                const issueNumber = project.projectDetails.issueNumber || 'ISS-1001';

                const canEdit = checkUserCanEdit(project);
                const assignedDisplay =
                  project.projectDetails.assignedToName ||
                  project.projectDetails.frcName ||
                  'Designated Assignee';

                return (
                  <div
                    key={project.id}
                    className="bg-white rounded-3xl border border-stone-200/90 shadow-sm hover:shadow-md hover:border-stone-300 transition-all flex flex-col justify-between overflow-hidden group"
                  >
                    {/* Card Body */}
                    <div className="p-6 space-y-4">
                      {/* Identifiers Header & Access Status */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200 shadow-2xs">
                            Issue #{issueNumber}
                          </span>
                          {canEdit ? (
                            <span className="inline-flex items-center gap-1 text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-semibold border border-emerald-200">
                              <Unlock className="w-3 h-3 text-emerald-600" />
                              Editable
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full font-semibold border border-amber-200">
                              <Lock className="w-3 h-3 text-amber-600" />
                              View-Only
                            </span>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => onDeleteProject(project.id)}
                          className="text-stone-300 hover:text-rose-600 p-1 rounded-md transition-colors opacity-0 group-hover:opacity-100"
                          title="Delete this project from portfolio"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Title & Description */}
                      <div className="space-y-1.5">
                        <h3 className="text-sm font-bold text-stone-900 group-hover:text-blue-700 transition-colors line-clamp-2 leading-snug">
                          {project.projectDetails.issueTitle}
                        </h3>
                        <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
                          {project.projectDetails.issueDescription ||
                            'Governance requirements and analytical remediation workspace.'}
                        </p>
                      </div>

                      {/* Assignee Box */}
                      <div className="p-2.5 bg-stone-50 rounded-xl border border-stone-200 text-xs flex items-center justify-between">
                        <span className="text-[11px] text-stone-500 flex items-center gap-1">
                          <User className="w-3 h-3 text-stone-400" />
                          Assigned To:
                        </span>
                        <span className="font-semibold text-stone-900 text-xs truncate max-w-[160px]" title={project.projectDetails.assignedToEmail || assignedDisplay}>
                          {assignedDisplay}
                        </span>
                      </div>

                      {/* Governance Personnel */}
                      <div className="pt-2 border-t border-stone-100 grid grid-cols-2 gap-2 text-[11px]">
                        <div>
                          <span className="text-stone-400 block font-medium">Requirements Lead</span>
                          <span className="font-semibold text-stone-800 truncate block">
                            {project.projectDetails.frcName}
                          </span>
                        </div>
                        <div>
                          <span className="text-stone-400 block font-medium">Development Lead</span>
                          <span className="font-semibold text-stone-800 truncate block">
                            {project.projectDetails.analystName}
                          </span>
                        </div>
                      </div>

                      {/* Waterfalls Selector & Counter */}
                      <div className="pt-2 border-t border-stone-100 space-y-1.5">
                        <div className="flex items-center justify-between text-[11px] text-stone-500">
                          <span className="font-medium flex items-center gap-1 text-purple-900">
                            <Layers className="w-3.5 h-3.5 text-purple-600" />
                            Waterfalls ({project.waterfalls.length})
                          </span>
                          <span className="font-mono text-stone-600">
                            {totalProjSteps} {totalProjSteps === 1 ? 'step' : 'steps'}
                          </span>
                        </div>

                        {/* Waterfall selector dropdown if more than 1 waterfall */}
                        {project.waterfalls.length > 1 ? (
                          <select
                            value={currentSelectedWfId}
                            onChange={(e) =>
                              setSelectedWaterfallByProject((prev) => ({
                                ...prev,
                                [project.id]: e.target.value,
                              }))
                            }
                            className="w-full text-[11px] px-2.5 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800 focus:outline-hidden focus:ring-1 focus:ring-purple-500"
                          >
                            {project.waterfalls.map((wf) => (
                              <option key={wf.id} value={wf.id}>
                                {wf.name} ({wf.rows?.length || 0} steps)
                              </option>
                            ))}
                          </select>
                        ) : (
                          <div className="text-[11px] font-medium text-stone-700 bg-stone-50 px-2.5 py-1.5 rounded-lg border border-stone-200 truncate">
                            {project.waterfalls[0]?.name || 'Initial Waterfall'}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Card Actions Footer */}
                    <div className="p-4 bg-stone-50/70 border-t border-stone-100 flex items-center justify-between gap-2">
                      {canEdit ? (
                        <button
                          type="button"
                          onClick={() => {
                            const wfName = prompt(
                              `Add new waterfall to project "${project.projectDetails.issueTitle}":\nEnter Waterfall Name:`
                            );
                            if (wfName && wfName.trim()) {
                              onAddWaterfallToProject(project.id, wfName.trim());
                            }
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-semibold text-purple-700 hover:text-purple-900 hover:bg-purple-50 rounded-lg transition-colors"
                          title="Add an additional waterfall to this project"
                        >
                          <Plus className="w-3 h-3 text-purple-600" />
                          <span>Add Waterfall</span>
                        </button>
                      ) : (
                        <span className="text-[11px] text-stone-400 italic">
                          Assigned to {assignedDisplay}
                        </span>
                      )}

                      <button
                        type="button"
                        onClick={() => onOpenProject(project.id, currentSelectedWfId)}
                        className={`inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold rounded-xl transition-all shadow-xs ${
                          canEdit
                            ? 'bg-stone-900 hover:bg-blue-600 text-white'
                            : 'bg-stone-800 hover:bg-stone-700 text-stone-100'
                        }`}
                      >
                        <span>{canEdit ? 'Open Workspace' : 'View Project'}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-stone-200 bg-white py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-stone-700">Requirements Waterfall</span>
            <span>•</span>
            <span>Enterprise Project Portfolio &amp; Issue Resolution</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span className="text-emerald-700 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Auditable Governance
            </span>
            <span>•</span>
            <span className="text-stone-600">
              Active Projects: <strong className="font-bold text-stone-800">{projects.length}</strong>
            </span>
          </div>
        </div>
      </footer>

      {/* Unified Create Project / Add Waterfall Modal */}
      <CreateProjectOrWaterfallModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        existingProjects={projects}
        initialQuery={searchQuery}
        onCreateNewProject={onCreateProject}
        onAddWaterfallToExistingProject={onAddWaterfallToProject}
        currentUser={currentUser}
      />
    </div>
  );
};
