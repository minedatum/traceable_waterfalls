import React, { useRef, useState } from 'react';
import {
  RotateCcw,
  Download,
  FolderSync,
  Briefcase,
  UserCheck,
  PlayCircle,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';
import { ProjectAuditReport, UserRole } from '../types';

interface HeaderProps {
  report: ProjectAuditReport;
  userRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onOpenAuditLogs: () => void;
  auditLogsCount: number;
  onFilesSelected: (files: FileList) => void;
  onLoadSample: () => void;
  onOpenRules: () => void;
  onOpenExport: () => void;
  onOpenScaffold: () => void;
  isUsingSample: boolean;
  folderName: string;
  onResetToCleanSlate?: () => void;
  onLoadSampleDemo?: () => void;
  waterfallRowsCount?: number;
  onRefreshData?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  report,
  userRole,
  onRoleChange,
  onOpenAuditLogs,
  auditLogsCount,
  onFilesSelected,
  onLoadSample,
  onOpenRules,
  onOpenExport,
  onOpenScaffold,
  isUsingSample,
  folderName,
  onResetToCleanSlate,
  onLoadSampleDemo,
  waterfallRowsCount = 0,
  onRefreshData,
}) => {
  const isInsideIframe = typeof window !== 'undefined' && window.self !== window.top;

  const handleOpenNewTab = () => {
    const url = window.location.href;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <header id="header-waterfall-auditor" className="bg-white border-b border-stone-200 sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        {/* Brand - Path removed cleanly as requested */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-stone-900 flex items-center justify-center text-white shrink-0 shadow-xs">
            <FolderSync className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-bold text-stone-900 tracking-tight">
              eGRC Requirements Waterfall
            </h1>
            <p className="text-xs text-stone-500 truncate max-w-md">
              Parallel Dual-Persona Workspace &amp; Governance Traceability
            </p>
          </div>
        </div>

        {/* Dual-Role View Segmented Toggle (View / Mode) */}
        <div className="flex items-center justify-center">
          <div
            id="role-toggle-container"
            className="inline-flex rounded-xl border border-stone-300 bg-stone-100 p-1 shadow-inner text-xs font-semibold"
          >
            <button
              type="button"
              id="role-btn-frc"
              onClick={() => onRoleChange('frc')}
              className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg transition-all ${
                userRole === 'frc'
                  ? 'bg-white text-emerald-900 font-bold shadow-xs border border-emerald-200/60'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Briefcase className={`w-3.5 h-3.5 ${userRole === 'frc' ? 'text-emerald-600' : 'text-stone-400'}`} />
              FRC Workspace
            </button>

            <button
              type="button"
              id="role-btn-analyst"
              onClick={() => onRoleChange('analyst')}
              className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg transition-all ${
                userRole === 'analyst'
                  ? 'bg-white text-blue-900 font-bold shadow-xs border border-blue-200/60'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <UserCheck className={`w-3.5 h-3.5 ${userRole === 'analyst' ? 'text-blue-600' : 'text-stone-400'}`} />
              Analyst Workspace
            </button>
          </div>
        </div>

        {/* Global Action Controls: Refresh Data, Reset, and ZIP Download */}
        <div className="flex items-center flex-wrap gap-2 justify-end">
          {/* New "Refresh Data" Button with email notification trigger */}
          {onRefreshData && (
            <button
              id="btn-refresh-data"
              type="button"
              onClick={onRefreshData}
              className="inline-flex items-center px-3.5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg transition-all shadow-xs gap-1.5"
              title="Refresh all analytical steps and notify the Project Team via email"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Refresh Data
            </button>
          )}

          {/* Reset Demo back to Clean Slate (shown in FRC view) */}
          {userRole !== 'analyst' && onResetToCleanSlate && (
            <button
              id="btn-reset-clean-slate"
              type="button"
              onClick={() => {
                if (window.confirm('Reset workspace to a 100% clean slate with 0 steps and 0 progress for first-time leadership demo?')) {
                  onResetToCleanSlate();
                }
              }}
              className="inline-flex items-center px-2.5 py-1.5 text-xs font-medium text-stone-700 hover:text-rose-700 bg-stone-100 hover:bg-rose-50 border border-stone-200 hover:border-rose-300 rounded-lg transition-colors shadow-2xs"
              title="Reset all steps and progress back to clean first-time use state"
            >
              <RotateCcw className="w-3.5 h-3.5 mr-1 text-stone-500" />
              Reset Demo
            </button>
          )}

          {/* Optional Load Sample Data for demonstration (shown in FRC view) */}
          {userRole !== 'analyst' && waterfallRowsCount === 0 && onLoadSampleDemo && (
            <button
              id="btn-load-sample-demo"
              type="button"
              onClick={onLoadSampleDemo}
              className="inline-flex items-center px-2.5 py-1.5 text-xs font-medium text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 border border-stone-200 rounded-lg transition-colors"
              title="Quickly populate sample waterfall steps to show leadership what completed steps look like"
            >
              <PlayCircle className="w-3.5 h-3.5 mr-1 text-stone-500" />
              Load Sample Steps
            </button>
          )}

          {/* Direct 1-Click Backup Download for Local Drive */}
          <a
            id="btn-download-workspace-zip"
            href="/workspace_full_backup.zip"
            download="egrc-waterfall-workspace-backup.zip"
            className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-stone-800 bg-stone-100 hover:bg-stone-200 border border-stone-300 rounded-lg transition-colors shadow-2xs"
            title="Download full project archive as ZIP to save to your local H: drive"
          >
            <Download className="w-3.5 h-3.5 mr-1.5 text-stone-700" />
            Download ZIP
          </a>

          {isInsideIframe && (
            <button
              id="btn-open-new-tab"
              type="button"
              onClick={handleOpenNewTab}
              className="inline-flex items-center px-2.5 py-1.5 text-xs font-medium text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors border border-stone-200"
              title="Open app in a full window tab to enable native file system writing"
            >
              <ExternalLink className="w-3.5 h-3.5 text-stone-500 mr-1" />
              New Tab
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

